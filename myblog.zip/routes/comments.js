const express = require('express');
const router = express.Router();
const checkLogin = require('../middlewares/check').checkLogin;

router.post('/', checkLogin, function(req, res, next){
	res.send('��������');
})

router.get('/:commentId/remove', checkLogin, function(req, res, next){
	res.send('ɾ������');
})

module.exports = router;
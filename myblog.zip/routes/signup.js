const express = require('express')
const router = express.Router()

const checkNotLogin = require('../middlewares/check').checkNotLogin

// GET /signup ע��ҳ
router.get('/', checkNotLogin, function (req, res, next) {
  res.send('ע��ҳ')
})

// POST /signup �û�ע��
router.post('/', checkNotLogin, function (req, res, next) {
  res.send('ע��')
})

module.exports = router